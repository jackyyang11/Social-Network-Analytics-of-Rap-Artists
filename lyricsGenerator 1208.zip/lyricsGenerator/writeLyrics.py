# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import lyricsgenius as genius
import os


artistList=("Eminem","Dr.Dre","Lil Wayne","Tupac","Jay Z")

api = genius.Genius("_zTmTfoL_xkTx_yZ46bgrtCV5VjVtluLcTmgc9ZuqGo8Mdax4SjR4ca1AejimcKg")

for artistName in artistList:
    try:
    # Create target Directory
        os.mkdir(str(artistName))
        print("Directory " , artistName,  " Created ") 
    except FileExistsError:
        print("Directory " , artistName,  " already exists")
    
    artist = api.search_artist(artistName, max_songs=9)
    q=artist.save_lyrics()
    for i in range(0,len(q['songs'])):
        lyrics=q['songs'][i]['lyrics']
        songname=str(q['songs'][i]['title'])+".txt"
        path=str(artistName)+'/'+songname
        fo=open(path,'w')
        fo.write(lyrics)
        fo.close()
